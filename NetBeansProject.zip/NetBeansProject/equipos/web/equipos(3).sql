-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 20-03-2018 a las 11:20:53
-- Versión del servidor: 5.7.21-0ubuntu0.17.10.1
-- Versión de PHP: 7.1.11-0ubuntu0.17.10.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `equipos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `equipos`
--

CREATE TABLE `equipos` (
  `codEquipo` int(11) NOT NULL,
  `nombre` varchar(40) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `liga` int(11) NOT NULL,
  `fundacion` int(11) NOT NULL,
  `localidad` varchar(30) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `imagen` varchar(45) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `equipos`
--

INSERT INTO `equipos` (`codEquipo`, `nombre`, `liga`, `fundacion`, `localidad`, `imagen`) VALUES
(1111, 'Real Madrid', 33, 1902, 'Madrid', 'RealMadrid.png'),
(1112, 'Barcelona', 24, 1899, 'Barcelona', 'Barcelona.png'),
(1113, 'Atlético de Madrid', 10, 1903, 'Madrid', 'Atletico.png'),
(1114, 'Valéncia', 6, 1919, 'Valéncia', 'Valencia.png'),
(1115, 'Athletic Club', 8, 1898, 'Bilbao', 'Atletic.png'),
(1116, 'Sevilla', 1, 1890, 'Sevilla', 'Sevilla.png'),
(1117, 'Espanyol', 0, 1900, 'Barcelona', 'Espanyol.png'),
(1118, 'Real Sociedad', 2, 1909, 'San Sebastián', 'RealSociedad.png'),
(1119, 'Real Zaragoza', 0, 1932, 'Zaragoza', 'RealZaragoza.png'),
(1120, 'Betis', 1, 1907, 'Sevilla', 'Betis.png'),
(1121, 'Deportivo de la Coruña', 1, 1906, 'La Coruña', 'Deportivo.png'),
(1122, 'Celta de Vigo', 0, 1923, 'Vigo', 'Celta.png'),
(1123, 'Valladoid', 0, 1928, 'Valladoid', 'Valladoid.png'),
(1124, 'Racing de Santander', 0, 1913, 'Santander', 'Santander.png'),
(1125, 'Sporting de Gijón', 0, 1905, 'Gijón', 'Gijon.png'),
(1126, 'Osasuna', 0, 1920, 'Pamplona ', 'Osasuna.png'),
(1127, 'Real Oviedo', 0, 1926, 'Oviedo', 'Oviedo.png'),
(1128, 'Mallorca', 0, 1916, 'Mallorca', 'Mallorca.png'),
(1129, 'Las Palmas', 0, 1949, 'Las Palmas', 'LasPalmas.png'),
(1130, 'Villarreal', 0, 1923, 'Villarreal', 'Villarreal.png'),
(1131, 'Málaga', 0, 1948, 'Málaga', 'Malaga.png');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `equipos`
--
ALTER TABLE `equipos`
  ADD PRIMARY KEY (`codEquipo`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
